# ReliefVue logo package v01

Upload reliefvue-submission-768.jpg: actual JPEG signature verified FF-D8-FF; decoded by Sharp as JPEG, 768 x 768, 28,639 bytes (0.029 MB). Browser screenshot bytes were initially saved with the wrong .png suffix; the .jpg filename corrects that suffix without altering the verified JPEG bytes. Original selected B elephant and actual Alegreya Sans Bold wordmark. Under 20 MB and 0.5 MB; platform recompression still needs checking after upload.

Review candidates: reliefvue-flat-transparent-candidate.png (1200 x 920), reliefvue-flat-candidate.svg (editable vector paths), reliefvue-icon-512-candidate.png (512 x 512, ivory background). Flat silhouette is a simplified reconstruction requiring user approval, not an exact approved master.

selected-source.png preserves the original selected board. submission-render.html retains the composition and bundled font; license included. Rejected 3D transparent attempts had glow and negative-space defects and are excluded. Clean transparent 3D master still pending. App and brandbook master not replaced. No trademark clearance implied.
